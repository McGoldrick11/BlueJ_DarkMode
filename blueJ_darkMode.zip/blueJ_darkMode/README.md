# BlueJ Dark Theme

## Installation

Replace all contents of the folder ```path/to/BlueJ/lib/stylesheets``` with the files in this project.

Credit goes to https://github.com/t-ye/bluej-dark-theme/ for this project's inspiration.
